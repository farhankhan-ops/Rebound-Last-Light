extends Node2D
class_name ReboundPlayer

signal shield_activated

@export var move_speed: float = 330.0
@export var shield_radius: float = 66.0
@export var shield_duration: float = 0.28
@export var shield_cooldown_time: float = 0.95

var shield_time: float = 0.0
var shield_cooldown: float = 0.0
var arena: Rect2 = Rect2(64, 108, 1152, 552)

func _process(delta: float) -> void:
	shield_time = maxf(shield_time - delta, 0.0)
	shield_cooldown = maxf(shield_cooldown - delta, 0.0)
	var direction := Vector2.ZERO
	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT): direction.x -= 1.0
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT): direction.x += 1.0
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP): direction.y -= 1.0
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN): direction.y += 1.0
	if direction.length_squared() > 0.0:
		position += direction.normalized() * move_speed * delta
	position.x = clampf(position.x, arena.position.x + 23.0, arena.end.x - 23.0)
	position.y = clampf(position.y, 300.0, arena.end.y - 23.0)
	queue_redraw()

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_SPACE and shield_cooldown <= 0.0:
			shield_time = shield_duration
			shield_cooldown = shield_cooldown_time
			shield_activated.emit()

func activate_shield() -> void:
	if shield_cooldown <= 0.0:
		shield_time = shield_duration
		shield_cooldown = shield_cooldown_time
		shield_activated.emit()

func _draw() -> void:
	if shield_time > 0.0:
		draw_circle(Vector2.ZERO, shield_radius, Color(0.20, 0.92, 0.78, 0.10))
		draw_arc(Vector2.ZERO, shield_radius, 0.0, TAU, 64, Color("#7CF7D2"), 3.0, true)
	draw_circle(Vector2.ZERO, 23.0, Color("#123D3B"))
	draw_circle(Vector2.ZERO, 18.0, Color("#55E6C4"))
	draw_circle(Vector2.ZERO, 7.0, Color("#E8FFF8"))
	draw_string(ThemeDB.fallback_font, Vector2(-19, -31), "YOU", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("#B9FFF0"))
