extends Node2D
class_name ReboundEnemy

@export var max_health: int = 2
var health: int = 2
var enemy_index: int = 0

func configure(index: int, start_position: Vector2, hit_points: int = 2) -> void:
    enemy_index = index
    position = start_position
    max_health = hit_points
    health = hit_points
    queue_redraw()

func take_damage(amount: int = 1) -> bool:
    health = maxi(health - amount, 0)
    queue_redraw()
    return health == 0

func is_alive() -> bool:
    return health > 0

func _draw() -> void:
    if health > 0:
        draw_circle(Vector2.ZERO, 34.0, Color("#351C31"))
        draw_arc(Vector2.ZERO, 28.0, 0.0, TAU, 48, Color("#FF7185"), 3.0, true)
        draw_circle(Vector2.ZERO, 13.0, Color("#FFC0CB"))
        for pip in range(max_health):
            var pip_color := Color("#FF9AAA") if pip < health else Color("#3D4A5B")
            draw_circle(Vector2(-9.0 + float(pip) * 18.0, -45.0), 4.0, pip_color)
    else:
        draw_circle(Vector2.ZERO, 31.0, Color("#202D3B"))
        draw_arc(Vector2.ZERO, 21.0, 0.0, TAU, 48, Color("#607188"), 2.0, true)
        draw_line(Vector2(-10,-10), Vector2(10,10), Color("#71839A"), 3.0)
        draw_line(Vector2(-10,10), Vector2(10,-10), Color("#71839A"), 3.0)
