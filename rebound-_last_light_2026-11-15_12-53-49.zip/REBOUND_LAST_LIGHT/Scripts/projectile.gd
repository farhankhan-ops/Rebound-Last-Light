extends Node2D
class_name ReboundProjectile

@export var speed: float = 255.0
var direction: Vector2 = Vector2.DOWN
var source_index: int = -1
var reflected: bool = false
var active: bool = true

func configure(start_position: Vector2, travel_direction: Vector2, source: int) -> void:
    position = start_position
    direction = travel_direction.normalized()
    source_index = source

func reflect() -> void:
    if not reflected:
        direction = -direction
        speed *= 1.25
        reflected = true
        queue_redraw()

func _process(delta: float) -> void:
    if active:
        position += direction * speed * delta
        queue_redraw()

func _draw() -> void:
    var tint := Color("#65EAD6") if reflected else Color("#FFAD66")
    draw_circle(Vector2.ZERO, 11.0, Color(tint.r, tint.g, tint.b, 0.18))
    draw_circle(Vector2.ZERO, 5.5, tint)
