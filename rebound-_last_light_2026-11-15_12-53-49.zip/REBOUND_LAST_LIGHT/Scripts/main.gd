extends Node2D

const PLAYER_SCENE: PackedScene = preload("res://Scenes/Player.tscn")
const ENEMY_SCENE: PackedScene = preload("res://Scenes/Enemy.tscn")
const PROJECTILE_SCENE: PackedScene = preload("res://Scenes/Projectile.tscn")
const VIEW_SIZE := Vector2(1280.0, 720.0)
const ARENA := Rect2(64.0, 108.0, 1152.0, 552.0)
const ENEMY_POSITIONS: Array[Vector2] = [Vector2(280,190), Vector2(640,170), Vector2(1000,190)]
const MAX_LIVES := 3
const TIME_LIMIT := 75.0

@onready var player: ReboundPlayer = $Player
@onready var enemies_root: Node2D = $Enemies
@onready var projectiles_root: Node2D = $Projectiles

var enemies: Array[ReboundEnemy] = []
var game_state := "title"
var lives := MAX_LIVES
var score := 0
var parry_count := 0
var destroyed_count := 0
var remaining_time := TIME_LIMIT
var fire_timer := 0.9
var next_enemy_index := 0

func _ready() -> void:
	_reset_game()

func _create_enemies() -> void:
	for child in enemies_root.get_children():
		child.queue_free()
	enemies.clear()
	for i in range(ENEMY_POSITIONS.size()):
		var enemy: ReboundEnemy = ENEMY_SCENE.instantiate() as ReboundEnemy
		enemies_root.add_child(enemy)
		enemy.configure(i, ENEMY_POSITIONS[i], 2)
		enemies.append(enemy)

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_ENTER and game_state != "playing":
			_reset_game()
			game_state = "playing"
		elif event.keycode == KEY_SPACE and game_state == "playing":
			player.activate_shield()

func _process(delta: float) -> void:
	if game_state != "playing":
		queue_redraw()
		return
	remaining_time = maxf(remaining_time - delta, 0.0)
	fire_timer -= delta
	if fire_timer <= 0.0:
		_fire_enemy_shot()
		fire_timer = 1.15
	_check_projectile_collisions()
	destroyed_count = 0
	for enemy in enemies:
		if not enemy.is_alive():
			destroyed_count += 1
	if destroyed_count == enemies.size():
		game_state = "won"
	elif lives <= 0 or remaining_time <= 0.0:
		game_state = "lost"
	queue_redraw()

func _fire_enemy_shot() -> void:
	for offset in range(enemies.size()):
		var index := (next_enemy_index + offset) % enemies.size()
		var enemy := enemies[index]
		if enemy.is_alive():
			var direction: Vector2 = (player.position - enemy.position).normalized()
			if direction.length_squared() == 0.0:
				direction = Vector2.DOWN
			var shot: ReboundProjectile = PROJECTILE_SCENE.instantiate() as ReboundProjectile
			projectiles_root.add_child(shot)
			shot.configure(enemy.position + direction * 30.0, direction, index)
			next_enemy_index = (index + 1) % enemies.size()
			return

func _check_projectile_collisions() -> void:
	for shot in projectiles_root.get_children():
		if not is_instance_valid(shot):
			continue
		if not shot.reflected:
			if player.shield_time > 0.0 and shot.position.distance_to(player.position) <= player.shield_radius:
				shot.reflect()
				parry_count += 1
				score += 20
			elif shot.position.distance_to(player.position) <= 26.0:
				lives -= 1
				shot.queue_free()
				continue
		else:
			var source: int = shot.source_index
			if source >= 0 and source < enemies.size() and shot.position.distance_to(enemies[source].position) <= 36.0:
				enemies[source].take_damage(1)
				score += 100
				shot.queue_free()
				continue
		if not ARENA.grow(40.0).has_point(shot.position):
			shot.queue_free()

func _reset_game() -> void:
	for shot in projectiles_root.get_children():
		shot.queue_free()
	_create_enemies()
	player.position = Vector2(640,570)
	player.shield_time = 0.0
	player.shield_cooldown = 0.0
	lives = MAX_LIVES
	score = 0
	parry_count = 0
	destroyed_count = 0
	remaining_time = TIME_LIMIT
	fire_timer = 0.9
	next_enemy_index = 0
	game_state = "title"
	queue_redraw()

func _draw() -> void:
	var font := ThemeDB.fallback_font
	draw_rect(Rect2(Vector2.ZERO, VIEW_SIZE), Color("#070B14"), true)
	var restoration := float(destroyed_count) * 0.018
	draw_rect(ARENA, Color(0.025 + restoration, 0.045 + restoration, 0.075 + restoration, 1.0), true)
	for x in range(0, 1281, 40):
		draw_line(Vector2(x,0), Vector2(x,720), Color(0.18,0.25,0.34,0.20), 1.0)
	for y in range(0, 721, 40):
		draw_line(Vector2(0,y), Vector2(1280,y), Color(0.18,0.25,0.34,0.20), 1.0)
	draw_rect(ARENA, Color("#31445B"), false, 2.0)
	draw_string(font, Vector2(68,47), "REBOUND // LAST LIGHT", HORIZONTAL_ALIGNMENT_LEFT, -1, 25, Color("#9CF5D8"))
	draw_string(font, Vector2(690,46), "TIME " + str(int(ceil(remaining_time))), HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color("#DCE7F2"))
	draw_string(font, Vector2(865,46), "LIVES " + str(lives), HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color("#FFB4B4"))
	draw_string(font, Vector2(1010,46), "SCORE " + str(score), HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color("#F8D88A"))
	draw_string(font, Vector2(70,88), "DESTROYED MACHINES: " + str(destroyed_count) + "/3", HORIZONTAL_ALIGNMENT_LEFT, -1, 15, Color("#A9B8CC"))
	var shield_status := "READY" if player.shield_cooldown <= 0.0 else "RECHARGING"
	draw_string(font, Vector2(930,88), "PULSE: " + shield_status, HORIZONTAL_ALIGNMENT_LEFT, -1, 15, Color("#7CF7D2") if player.shield_cooldown <= 0.0 else Color("#8795A8"))
	draw_string(font, Vector2(68,697), "MOVE: WASD / ARROWS     PULSE SHIELD: SPACE     START / RETRY: ENTER", HORIZONTAL_ALIGNMENT_LEFT, -1, 15, Color("#9BAFC5"))
	if game_state == "title":
		_draw_panel("REBOUND", "LAST LIGHT", "The machines fire first. You decide where the shot ends.", "Move with WASD. Tap SPACE when a bolt reaches your shield.", "PRESS ENTER TO START")
	elif game_state == "won":
		_draw_panel("THE LIGHT RETURNS", "", "You turned the machines' attacks against them.", "Successful parries: " + str(parry_count) + "     Final score: " + str(score), "PRESS ENTER TO PLAY AGAIN")
	elif game_state == "lost":
		_draw_panel("THE SIGNAL FELL SILENT", "", "Wait until a bolt is close, then tap SPACE to parry.", "You destroyed " + str(destroyed_count) + " of 3 machines.", "PRESS ENTER TO TRY AGAIN")

func _draw_panel(title: String, subtitle: String, line1: String, line2: String, prompt: String) -> void:
	var font := ThemeDB.fallback_font
	draw_rect(Rect2(225,205,830,330), Color(0.015,0.025,0.055,0.94), true)
	draw_rect(Rect2(225,205,830,330), Color("#56718B"), false, 2.0)
	draw_string(font, Vector2(270,285), title, HORIZONTAL_ALIGNMENT_CENTER, 740, 42 if subtitle == "" else 48, Color("#9CF5D8"))
	if subtitle != "":
		draw_string(font, Vector2(270,326), subtitle, HORIZONTAL_ALIGNMENT_CENTER, 740, 24, Color("#F5F7FA"))
	draw_string(font, Vector2(275,374), line1, HORIZONTAL_ALIGNMENT_CENTER, 730, 16, Color("#D9E5F1"))
	draw_string(font, Vector2(275,414), line2, HORIZONTAL_ALIGNMENT_CENTER, 730, 16, Color("#AFC2D5"))
	draw_string(font, Vector2(275,493), prompt, HORIZONTAL_ALIGNMENT_CENTER, 730, 20, Color("#FFD58B"))
